#!/usr/bin/env bash

kubectl apply -f green-controller.json
