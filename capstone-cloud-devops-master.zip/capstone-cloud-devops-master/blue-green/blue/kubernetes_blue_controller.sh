#!/usr/bin/env bash

kubectl apply -f blue-controller.json
